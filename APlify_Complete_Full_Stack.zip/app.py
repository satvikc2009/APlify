
from flask import Flask
from auth import auth_bp
from chatbot.routes import chatbot_bp
from dashboard.routes import dashboard_bp
from auth.models import db
from flask_login import LoginManager
from auth.models import User
from config import Config

app = Flask(__name__)
app.config.from_object(Config)
db.init_app(app)

login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

app.register_blueprint(auth_bp)
app.register_blueprint(chatbot_bp)
app.register_blueprint(dashboard_bp)

@app.route("/")
def index():
    return "<h1>Welcome to APlify — Simplifying AP with AI</h1>"

if __name__ == "__main__":
    app.run(debug=True)
